export default {
  name: 'icon',
};
